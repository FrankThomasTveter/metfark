# farkRPackage 0.2.0

* Changed name from exampleDataPackage to farkRPackage
* Added a `NEWS.md` file to track changes to the package.



